import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from tkinter import ttk
import shutil
import os
import string

window = tk.Tk()
window.title('SM')
window.geometry("200x240")
window.configure(background='white')
icon= tk.PhotoImage(file='icon.png')
window.tk.call('wm', 'iconphoto', window._w, icon)


src_button= tk.Button(window, text="Source Folder", fg = 'blue', bg = 'white', width=15, command=lambda: source())
src_button.pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)

des_button= tk.Button(window, text="Destination Folder", fg = 'green', bg = 'white', width=15, command=lambda: destination())
des_button.pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)


v = tk.IntVar()
tk.Label(window, text = "Please Select a file extension type", bg='white', justify = tk.LEFT).pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)
tk.Radiobutton(window, text='JPG', bg='white', variable=v, value=1).pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)
tk.Radiobutton(window, text='PNG', bg='white', variable=v, value=2).pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)
tk.Radiobutton(window, text='WMF', bg='white', variable=v, value=3).pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)
tk.Radiobutton(window, text='CDR', bg='white', variable=v, value=4).pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)
tk.Radiobutton(window, text='DWG', bg='white', variable=v, value=5).pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)


start_button= tk.Button(window, text="Start", bg = 'green', fg='white', width=5, command=lambda: the_work())
start_button.pack() #.grid(rowspan=1, columnspan=5, padx=5, pady=5)



def source():
    answer = filedialog.askdirectory(parent=window,initialdir=os.getcwd(),title="Please select a folder:")
    global src
    src = str(answer)

def destination():
    answer = filedialog.askdirectory(parent=window,initialdir=os.getcwd(),title="Please select a folder:")
    global dest
    dest = str(answer)

def the_work():
    path = src
    go_to = dest
    ftype = file_type(v.get())
    if os.path.isdir(path) and os.path.isdir(go_to) and ftype != "no":
        for root, dirs, Afiles, in os.walk(path):
            for file in Afiles:
                if ftype in file:
                    fp = (os.path.join(root,file))
                    shutil.copy(fp, go_to)
        messagebox.showinfo("Task", "Process Completed")
    else:
        messagebox.showinfo("Error", "Path or Extension Selection")
        

def file_type(x):
    switcher={
        1:'.jpg',
        2:'.png',
        3:'.wmf',
        4:'.cdr',
        5:'.dwg',
        }
    return switcher.get(x,"no")


window.mainloop()
input()
